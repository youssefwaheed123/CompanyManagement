#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
typedef struct
{
    int day;
    int month;
    int year;
}Date;
typedef struct
{
 int id;
 char firstname[20];
char lastname[20];
float salary;
Date dob;
char address[100];
char no[15];
char email[40];
}employees;
employees array[100];
int Load (employees* array) //load
{
     int i=0;
    char *p1;
    char d[]=",-\n";
    char recordString[10000];
    FILE *f1;
    f1=fopen("Company.txt","r");
    if(f1==NULL){
        printf("FILE NOT FOUND!!!");
        exit (1);
}
    while( fgets(recordString,1000,f1)!=NULL)
{
         p1=strtok(recordString,d);
         if(p1!=NULL)
           array[i].id=atoi(p1);
         p1=strtok(NULL,d);
         if(p1!=NULL)
          strcpy(array[i].firstname,p1);
         p1=strtok(NULL,d);
         if(p1!=NULL)
           strcpy( array[i].lastname,p1);
         p1=strtok(NULL,d);
         if(p1!=NULL)
            array[i].salary=atof(p1);
         p1=strtok(NULL,d);
         if(p1!=NULL)
            array[i].dob.day=atoi(p1);
         p1=strtok(NULL,d);
         if(p1!=NULL)
            array[i].dob.month=atoi(p1);
         p1=strtok(NULL,d);
         if(p1!=NULL)
            array[i].dob.year=atoi(p1);
         if(p1!=NULL)
            p1=strtok(NULL,d);
         if(p1!=NULL)
            strcpy(array[i].address,p1);
         p1=strtok(NULL,d);
         if(p1!=NULL)
            strcpy(array[i].no,p1);
         p1=strtok(NULL,d);
         if(p1!=NULL)
            strcpy(array[i].email,p1);
         i++;
          }
          fclose(f1);
    return i;

}
int Query(employees*array,int noOfEmployees) //query
{
    int i;
    char stringOfName[100];
    printf("Enter the employee's last name to start searching:\n");
    scanf(" %s",&stringOfName);
    int index=100;
    for(i=0;i<noOfEmployees;i++)
    {
        if (strcasecmp(stringOfName,array[i].lastname)==0)
        {
            index=i;
            printf("The id of the employee selected is %d\n",array[index].id);
    printf("The first name of the employee selected is %s\n",array[index].firstname);
    printf("The salary of the employee selected is %.3f\n",array[index].salary);
    printf("The date of birth of the employee selected is %d - %d - %d\n",array[index].dob.day,array[index].dob.month,array[index].dob.year);
    printf("The address of the selected employee is %s\n",array[index].address);
    printf("The phone number of the selected employee is %s\n",array[index].no);
    printf("The email of the selected employee is %s\n",array[index].email);
    printf("\n\n");

        }

    }
    if (index==100)
    {
        printf("No employee found\n");
        return 0;
    }

    return 0;

}
int isvalid(char*id) //checking validation of ID
{
    int i,x;
    for(i=0;i<strlen(id);i++)
    {
        if(isdigit(id[i])==0)
        {
            return 0;
        }
    }
return 1;
}


    int validPhoneNumber(char str[]){
    int x=strlen(str);
    if(x!=11)
        return 0;
    else if(str[0]!='0')
        return 0;
    else if(str[1]!='1')
        return 0;
    else return 1;

    }

    int validEmail(char str[]){
        int i;
        int x=strlen(str);
            if(isdigit(str[0])==1){
                    return 0;
                }
        int loc1=-1;
        int loc2=-1;

            for(i=0;i<x;i++){

             if(str[i]=='@')
                loc1=i;
                else if(str[i]=='.')
                loc2=i;

                }
        if (loc1==-1 ||loc2==-1)
            return 0;
        else if(loc1>loc2)
            return 0;
        else if(loc1<loc2)
            return 1;

    }

void add(employees *array,int * noOfEmployees ) //add
{
    int i,x;
    char id[3];
    int intId;
    *noOfEmployees+=1;
    char strNo[15];
    do{
    printf("\nAdd new valid employee's ID: ");
    scanf("%s",id);
    }while(isvalid(id)==0);
    intId=atoi(id);
    array[*noOfEmployees-1].id=intId;
    printf("\nAdd new employee's first name: ");
    scanf(" %s",array[*noOfEmployees-1].firstname);
    printf("\nAdd new employee's last name: ");
    scanf(" %s",array[*noOfEmployees-1].lastname);
    printf("\nAdd new employee's salary: ");
    scanf(" %f",&array[*noOfEmployees-1].salary);
    printf("\nAdd employee's day of birth: ");
    scanf(" %d",&array[*noOfEmployees-1].dob.day);
    printf("\nAdd employee's month of birth: ");
    scanf(" %d",&array[*noOfEmployees-1].dob.month);
    printf("\nAdd employee's year of birth: ");
    scanf(" %d",&array[*noOfEmployees-1].dob.year);
    getchar();
    printf("\nAdd new employee's address: ");
    gets(array[*noOfEmployees-1].address);
    do{
    printf("\nAdd new employee's valid phone number: ");
    scanf(" %s",array[*noOfEmployees-1].no);
    strcpy(strNo,array[*noOfEmployees-1].no);
    }while(validPhoneNumber(strNo)==0);
    char str[40];
     do
    {
        printf("\nAdd new employees valid email:") ;
        scanf("%s",array[*noOfEmployees-1].email);
        strcpy(str,array[*noOfEmployees-1].email);
    }
    while (validEmail(str)==0);
    printf("Employee is added successfully!\n");
}

int modify (employees* array) //modify
{
    char strNo[15],strEmail[40];
    int i;
    char id[3];
    do
    {
        printf("\nEnter a valid id of the employee you want to modify:") ;
        scanf("%s",id);
    }
    while (isvalid(id)==0);
    int n=atoi(id);
    int index=100;
    for(i=0;i<10;i++)
    {
        if (n==array[i].id)
        {
            index=i;
            break;
        }
    }
    if (index==100)
        {
            printf("No employee found\n");
            return 0;
        }
    printf("\nModify employee's first name: ");
    scanf("%s",array[index].firstname);
    printf("\nModify employee's last name: ");
    scanf("%s",array[index].lastname);
    printf("\nModify employee's salary: ");
    scanf(" %f",&array[index].salary);
    printf("\nModify employee's day of birth: ");
    scanf(" %d",&array[index].dob.day);
    printf("\nModify employee's month of birth: ");
    scanf(" %d",&array[index].dob.month);
    printf("\nModify employee's year of birth: ");
    scanf(" %d",&array[index].dob.year);
    getchar();
    printf("\nModify employee's address: ");
    gets(array[index].address);
    do{
    printf("\nModify employee's valid phone number: ");
    scanf("%s",array[index].no);
    strcpy(strNo,array[index].no);
    }while(validPhoneNumber(strNo)==0);
    do{
    printf("\nModify employee's valid email ");
    scanf("%s",array[index].email);
    strcpy(strEmail,array[index].email);
    }while (validEmail(strEmail)==0);
    printf("Employee is modified successfully!\n");
    return 0;
}
void saveData(employees*array,int noOfemployees) //saving data
{
    FILE* f1;
    f1=fopen("Company.txt","w");
    int i;
    for(i=0;i<noOfemployees;i++)
    {
         fprintf(f1,"%d,%s,%s,%.3f,%d-%d-%d,%s,%s,%s",array[i].id,array[i].firstname,array[i].lastname,array[i].salary,array[i].dob.day,array[i].dob.month,array[i].dob.year,array[i].address,array[i].no,array[i].email);
         fprintf(f1,"\n");
    }
    fclose(f1);
    printf("Data is saved successfully!\n");
}
void LastNameSort(employees*array, int noOfEmployees) //sorting by last name
{
    int i,j;
    employees tempArray[100];
    for (i = 0; i < noOfEmployees-1; i++)
    {
        for (j = 0; j < noOfEmployees-i-1; j++)
        {
            if (strcasecmp(array[j].lastname,array[j+1].lastname)>0)
            {
                tempArray[i]=array[j];
                array[j]=array[j+1];
                array[j+1]=tempArray[i];
            }
        }
    }
    printf("Data after being sorted by last name:\n");
    print(array,noOfEmployees);
}
void birthdaySort(employees*array, int noOfEmployees) //sorting by birthday
{
    int i,j;
    employees tempArray[100];
    for (i = 0; i < noOfEmployees-1; i++)
    {
        for (j = 0; j < noOfEmployees-i-1; j++)
        {
            if (array[j].dob.year>array[j+1].dob.year)
            {
                tempArray[i]=array[j];
                array[j]=array[j+1];
                array[j+1]=tempArray[i];
            }
            else if (array[j].dob.year==array[j+1].dob.year)
            {
               if(array[j].dob.month>array[j+1].dob.month)
               {
                   tempArray[i]=array[j];
                    array[j]=array[j+1];
                    array[j+1]=tempArray[i];
                }
            }
            else if (array[j].dob.month==array[j+1].dob.month)
            {
                if(array[j].dob.day>array[j+1].dob.day)
               {
                   tempArray[i]=array[j];
                    array[j]=array[j+1];
                    array[j+1]=tempArray[i];
                }

            }
        }
    }
    printf("Data after being sorted by date of birth:\n");
    print(array,noOfEmployees);

}
void salarySort(employees*array, int noOfEmployees) //sorting by salary
{
    int i,j;
    employees tempArray[100];
    for (i = 0; i < noOfEmployees-1; i++)
    {
        for (j = 0; j < noOfEmployees-i-1; j++)
        {
            if (array[j].salary>array[j+1].salary)
            {
                tempArray[i]=array[j];
                array[j]=array[j+1];
                array[j+1]=tempArray[i];
            }
        }
    }
    printf("Data after being sorted by salary:\n");
    print(array,noOfEmployees);

}
void print_options(employees*array,int noOfEmployees )
{
    int sort;
    printf("Enter a number to choose the way of printing the sorted data:\n");
    printf("1.Print data after sorting according to last name\n2.Print data after sorting according to date of birth\n3.Print data after sorting according to salary\n");
    scanf("%d",&sort);
    switch(sort)
    {
        case 1:
            {
                LastNameSort(array,noOfEmployees);
                break;
            }
        case 2:
            {
                birthdaySort(array,noOfEmployees);
                break;
            }
        case 3:
            {
                salarySort(array,noOfEmployees);
                break;
            }

    }
}
void Exit() //exit
{
    char answer[1];
    printf("Are you sure you want to exit(y/n)?\nWARNING!! ALL UNSAVED DATA WILL BE LOST");
    scanf("%s",answer);
    if (answer[0]=='y')
    {
        exit(1);
    }
    if(answer[0]!='y'&&answer[0]!='n')
    {
        printf("Invalid answer, please enter again\n");
        Exit();
    }


}
int delete_employee (employees array [],int *noOfEmployees) //delete
{
    int i;
    char lastname[20],firstname[20];
    char nullstr[20] = {"\0"};
    printf("enter the user last and first name you want to delete:");
    scanf("%s %s",lastname,firstname);
    int index=100;
    for(i=0;i<*noOfEmployees;i++)
        {
            if(strcasecmp (array[i].lastname,lastname)==0&&strcasecmp(array[i].firstname,firstname)==0)
                {
                    index=i;
                    break;
                }


        }
        if (index==100)
        {
            printf("ERORR!!! NO EMPLOYEE FOUND\n");
            return 0;

        }

    for(i=index;i<*noOfEmployees;i++)
    {
    strcpy(array[i].lastname,array[i+1].lastname);
    array[i].id=array[i+1].id;
    strcpy(array[i].firstname,array[i+1].firstname);
    array[i].salary=array[i+1].salary;
    array[i].dob.day=array[i+1].dob.day;
    array[i].dob.month=array[i+1].dob.month;
    array[i].dob.year=array[i+1].dob.year;
    strcpy(array[i].address,array[i+1].address);
    strcpy(array[i].no,array[i+1].no);
    strcpy(array[i].email,array[i+1].email);
    }
    printf("Employee is deleted successfully!\n");
    *noOfEmployees-=1;
    return 0;

}
void print(employees*array,int noOfEmployees) //print
{
    int i;
    for(i=0;i<noOfEmployees;i++)
    {
        printf("%d. ID:%d  FIRST NAME:%s  LAST NAME:%s  SALARY:%.3f  DATE:%d - %d - %d  ADDRESS:%s  NUMBER:%s  EMAIL:%s\n",i+1,array[i].id,array[i].firstname,array[i].lastname,array[i].salary,array[i].dob.day,array[i].dob.month,array[i].dob.year,array[i].address,array[i].no,array[i].email);
    }

}
int main()
{

    int noOfEmployees=Load(array);
    int i;
    int numberOffunction;
    printf("1.Query\n2.Add\n3.Delete\n4.Modify\n5.Print\n6.Save\n7.Exit\n");

    for(;;)
    {
        printf("Please enter the number of the function you want to choose as shown in the menu:\n");
        scanf("%d",&numberOffunction);
        switch(numberOffunction)
        {
        case 1:
            {
               Query(array,noOfEmployees);
               break;
            }
        case 2:
            {
                add (array,&noOfEmployees) ;
                break;
            }
        case 3:
            {
                delete_employee(array,&noOfEmployees);
                break;
            }
        case 4:
            {
                modify(array);
                break;
            }
        case 5:
            {
                print_options(array,noOfEmployees);
                break;
            }
        case 6:
            {
                saveData(array,noOfEmployees);
                break;
            }
        case 7:
            {
                Exit();
                break;

            }
        }

   }

return 0;
}
